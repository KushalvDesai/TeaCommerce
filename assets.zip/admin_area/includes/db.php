<?php

$con = mysqli_connect("193.203.184.167","u149605981_tea1","Catcake@2024","u149605981_tea1");

?>
