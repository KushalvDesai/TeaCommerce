<?php

$con = mysqli_connect("host","username","password","db name");

?>
